"""Local, bring-your-own-key execution.

A process exported with `promptflow export` collapses to a standalone
`process.py` that reads its API keys from environment variables and calls
Anthropic / fal / Brave directly. That makes it runnable *anywhere* — this
module is the CLI's support for running it on the user's own machine, with
the user's own keys, paying the providers directly (no PromptFlow tokens).

Two commands:
  - `promptflow keys`       — store/show BYOK API keys (~/.promptflow/keys.json)
  - `promptflow run-local`  — run an exported process.py with those keys
"""

from __future__ import annotations

import json
import os
import stat
import subprocess
import sys
from pathlib import Path
from typing import Dict

import typer

from promptflow_cli.config import config_dir


# The BYOK keys file. Separate from config.json so the platform API key and
# the provider keys are not tangled together. 0600 — it holds secrets.
_KEYS_FILE = "keys.json"

# Maps a friendly name to the env var the generated process.py expects.
_KEY_ENV = {
    "anthropic": "ANTHROPIC_API_KEY",
    "brave": "BRAVE_API_KEY",
    "fal": "FAL_KEY",
    "openai": "OPENAI_API_KEY",
    "elevenlabs": "ELEVEN_LABS_API_KEY",
}


def _keys_path() -> Path:
    return config_dir() / _KEYS_FILE


def _load_keys() -> Dict[str, str]:
    p = _keys_path()
    if not p.exists():
        return {}
    try:
        return json.loads(p.read_text("utf-8")) or {}
    except (json.JSONDecodeError, OSError):
        return {}


def _save_keys(keys: Dict[str, str]) -> None:
    d = config_dir()
    d.mkdir(parents=True, exist_ok=True)
    p = _keys_path()
    p.write_text(json.dumps(keys, indent=2) + "\n", "utf-8")
    try:
        p.chmod(stat.S_IRUSR | stat.S_IWUSR)  # 0600
    except OSError:
        pass  # Windows / some filesystems ignore chmod


def register(app: typer.Typer, console, err) -> None:
    """Wire the keys + run-local commands onto the main Typer app."""

    @app.command()
    def keys(
        set_key: str = typer.Option(
            None, "--set", help="Store a key as name=value "
            "(name: anthropic, brave, fal, openai, elevenlabs)."
        ),
        clear: str = typer.Option(
            None, "--clear", help="Remove a stored key by name."
        ),
    ) -> None:
        """Manage your own API keys for local (BYOK) process execution.

        Keys are stored at ~/.promptflow/keys.json (owner-only) and used by
        `run-local`. With no options, shows which keys are set.

            promptflow keys --set anthropic=sk-ant-...
            promptflow keys --set brave=BSA...
            promptflow keys                       # show what's stored
        """
        keys_store = _load_keys()

        if set_key:
            if "=" not in set_key:
                err.print("[red]✗[/red] Use --set name=value (e.g. --set brave=BSA...).")
                raise typer.Exit(code=1)
            name, value = set_key.split("=", 1)
            name = name.strip().lower()
            value = value.strip()
            if name not in _KEY_ENV:
                err.print(
                    f"[red]✗[/red] Unknown key '{name}'. "
                    f"Known: {', '.join(sorted(_KEY_ENV))}."
                )
                raise typer.Exit(code=1)
            if not value:
                err.print("[red]✗[/red] Empty value.")
                raise typer.Exit(code=1)
            keys_store[name] = value
            _save_keys(keys_store)
            console.print(f"  [green]\u2713[/green] Stored [bold]{name}[/bold] key.")
            return

        if clear:
            name = clear.strip().lower()
            if name in keys_store:
                del keys_store[name]
                _save_keys(keys_store)
                console.print(f"  [green]\u2713[/green] Cleared [bold]{name}[/bold] key.")
            else:
                console.print(f"  [dim]No '{name}' key was stored.[/dim]")
            return

        # No options — show status.
        console.print()
        console.print("  [bold]BYOK keys[/bold]   [dim](~/.promptflow/keys.json)[/dim]")
        for name, env_var in sorted(_KEY_ENV.items()):
            mark = "[green]set[/green]" if keys_store.get(name) else "[dim]not set[/dim]"
            console.print(f"    {name:12s} {mark}   [dim]\u2192 {env_var}[/dim]")
        console.print()
        console.print("  [dim]Set one with:  promptflow keys --set anthropic=sk-ant-...[/dim]")

    @app.command(name="run-local")
    def run_local(
        process_file: str = typer.Argument(
            ..., help="Path to an exported process.py (or its folder)."
        ),
        text: str = typer.Option(
            None, "--text", "-t", help="The text input for the process."
        ),
        dry_run: bool = typer.Option(
            False, "--dry-run", help="Show what would run without executing."
        ),
    ) -> None:
        """Run an exported process on your machine, with your own keys.

        Executes a collapsed process.py locally — it calls Anthropic / fal /
        Brave directly using the keys from `promptflow keys`. Nothing goes
        through PromptFlow's backend and no tokens are spent; you pay the
        providers directly.

            promptflow export <id>
            promptflow keys --set anthropic=sk-ant-... --set brave=BSA...
            promptflow run-local ./research-paper-web-search --text "quantum computing"
        """
        # Accept either a process.py path or the folder containing it.
        p = Path(process_file).expanduser()
        if p.is_dir():
            cand = p / "process.py"
            if not cand.is_file():
                err.print(f"[red]✗[/red] No process.py in {p}/.")
                raise typer.Exit(code=1)
            p = cand
        if not p.is_file():
            err.print(f"[red]✗[/red] File not found: {process_file}")
            raise typer.Exit(code=1)

        source = p.read_text("utf-8")

        # Substitute the <USER_TEXT> placeholder with the real input.
        # The generated file has:  USER_TEXT = "<USER_TEXT>"
        if text is not None:
            source = source.replace("<USER_TEXT>", text.replace('"', '\\"'))
        elif "<USER_TEXT>" in source:
            err.print(
                "[yellow]This process expects a text input.[/yellow] "
                "Re-run with --text \"your value\"."
            )
            raise typer.Exit(code=1)

        # Figure out which keys the process actually needs, from its imports.
        needs = []
        for name, env_var in _KEY_ENV.items():
            if env_var in source:
                needs.append((name, env_var))

        keys_store = _load_keys()
        env = dict(os.environ)
        missing = []
        for name, env_var in needs:
            val = keys_store.get(name) or os.environ.get(env_var)
            if val:
                env[env_var] = val
            else:
                missing.append((name, env_var))

        if missing:
            err.print("[yellow]Missing keys this process needs:[/yellow]")
            for name, env_var in missing:
                err.print(f"    {name}  ([dim]{env_var}[/dim])")
            err.print(
                "  Set them with:  "
                f"promptflow keys --set {missing[0][0]}=..."
            )
            raise typer.Exit(code=1)

        if dry_run:
            console.print(f"  [dim]Would run:[/dim] {p}")
            console.print(
                f"  [dim]With keys:[/dim] {', '.join(n for n, _ in needs) or 'none needed'}"
            )
            return

        console.print(f"  Running [bold]{p.name}[/bold] locally…")
        console.print(
            f"  [dim]Using your keys ({', '.join(n for n, _ in needs) or 'none'}) "
            f"— nothing is charged to PromptFlow.[/dim]"
        )
        console.print()

        # Run the (substituted) process with the local interpreter. We write
        # the substituted source to a temp file next to the original so its
        # relative paths (prompts/) still resolve.
        tmp = p.parent / ".process_run.py"
        try:
            tmp.write_text(source, "utf-8")
            proc = subprocess.run(
                [sys.executable, str(tmp)],
                env=env, cwd=str(p.parent),
                capture_output=True, text=True, timeout=600,
            )
        except subprocess.TimeoutExpired:
            err.print("[red]✗[/red] Process timed out after 10 minutes.")
            raise typer.Exit(code=1)
        finally:
            try:
                tmp.unlink()
            except OSError:
                pass

        if proc.stdout:
            console.print(proc.stdout.rstrip())
        if proc.returncode != 0:
            console.print()
            err.print("[red]✗[/red] The process exited with an error:")
            if proc.stderr:
                # Show the tail of the traceback — most useful part.
                tail = "\n".join(proc.stderr.rstrip().splitlines()[-12:])
                err.print(f"[dim]{tail}[/dim]")
            raise typer.Exit(code=1)

        console.print()
        console.print("  [green]\u2713[/green] Finished.")
