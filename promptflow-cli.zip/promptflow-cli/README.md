# promptflow-cli

The PromptFlow command-line tool. Discover, adapt, create, and publish
reusable AI processes from your terminal.

## The idea

Most AI work repeats work someone has already done. PromptFlow is a shared
database of *processes* — reusable, multi-step AI workflows. The CLI lets you:

- **search** the database before building anything,
- **adapt** an existing process to your need (cheaper than building new),
- **create** a process when nothing close exists,
- **publish** what you built so the next person reuses it.

Searching and adapting is the cheap path. Publishing is what keeps the
database worth searching. Both halves matter — that is the flywheel.

## Install

Requires Python 3.9+.

```bash
pip install -e .
```

This puts a `promptflow` command on your PATH.

## Quick start

```bash
promptflow login                       # authenticate this device via the browser
promptflow search "summarize a PDF"     # look for something reusable first
promptflow create "summarize a PDF and email me the result"
promptflow publish --process <process_id>
```

## Commands

| Command            | What it does                                              |
| ------------------ | --------------------------------------------------------- |
| `login`            | Authenticate this device (browser-approved, like `wrangler login`). |
| `logout`           | Remove the stored key from this machine.                  |
| `whoami`           | Show the account you are signed in as.                    |
| `search "<query>"` | Search the process database.                              |
| `adapt "<req>" -c`  | Adapt the closest existing process with a targeted change. |
| `create "<req>"`   | Create a process — adapts a match, or builds fresh.       |
| `publish --process`| Publish a process to the marketplace (needs one test run). |
| `version`          | Print the CLI version.                                    |

Run `promptflow <command> --help` for full options.

## Configuration

Config lives at `~/.promptflow/config.json` (the API key is stored `0600`).

| Setting    | Override with                          |
| ---------- | --------------------------------------- |
| Server URL | `--server` flag, or `PROMPTFLOW_SERVER` |
| API key    | `PROMPTFLOW_API_KEY`                    |

## How `create` and `adapt` work

Neither is a single API call — both orchestrate the backend:

```
create  =  plan  ->  execute  ->  poll status  ->  (publish)
adapt   =  plan  ->  fork_and_refine  ->  execute  ->  poll status  ->  (publish)
```

`plan` runs the database search internally and returns one of two intents:

- **design_process** — your request is genuinely new. The backend designs
  and saves the process as a draft; `create` commits it into your catalog.
- **execute** — a close process fits. `create` runs it, then saves the
  result as a process.

Either way you end with a working process. `publish` then lists it on the
marketplace — the backend requires one successful run first, as a quality
floor.

## Status

MVP. The five flywheel commands are implemented against the deployed
backend. `login` depends on the device-login endpoints being deployed
(`/api/promptflow/device/start|approve|poll`).
